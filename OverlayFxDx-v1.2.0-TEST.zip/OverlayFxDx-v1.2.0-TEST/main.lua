-- name: OverlayFxDX-v1.2.0
-- description: Advanced overlay system for COOPDX 1.5.1, Created by CrypticTM

if gGlobalSyncTable == nil then gGlobalSyncTable = {} end
if gGlobalSyncTable.overlay_mode == nil then gGlobalSyncTable.overlay_mode = 0 end

local showUI = false
local keybindsEnabled = true

local overlay_names = {
    "OFF/NORMAL",
    "N64 CRT",
    "WASHED COLORS",
    "RETRO CRT",
    "VHS",
    "GREEN",
    "LOW-RES",
    "GLITCH",
    "CRT DARK",
    "BLUR",
    "FILM",
    "HEAT HAZE",
    "UNDERWATER",
    "GRIDLOCK",
    "FUZZY SIGNAL",
    "SYNC LOSS",
    "OIRAM 88"
}

local prevPeriod = false
local prevComma = false

local list_timer = 0
local list_alpha = 0


local function screen()
    return djui_hud_get_screen_width(), djui_hud_get_screen_height()
end


local function rect(r,g,b,a)
    local w,h = screen()

    djui_hud_set_color(r,g,b,a)
    djui_hud_render_rect(0,0,w,h)
end


local function off()
end



-- N64 composite CRT
local function n64()

    local w,h = screen()

    -- slight warm composite tint
    rect(40,35,25,18)


    -- scanlines
    djui_hud_set_color(0,0,0,45)

    for y = 0,h,3 do
        djui_hud_render_rect(
            0,
            y,
            w,
            1
        )
    end


    -- subtle ghosting
    djui_hud_set_color(255,255,255,8)

    djui_hud_render_rect(
        2,
        0,
        w,
        h
    )

end



-- faded old display colors
local function washed()

    rect(180,170,120,35)


    local w,h = screen()

    djui_hud_set_color(255,220,160,12)

    djui_hud_render_rect(
        0,
        0,
        w,
        h
    )


    djui_hud_set_color(255,255,255,8)

    for y = 0,h,6 do
        djui_hud_render_rect(
            0,
            y,
            w,
            2
        )
    end

end



-- stronger classic CRT
local function retro_crt()

    local w,h = screen()


    rect(20,10,35,28)


    -- horizontal scanlines

    djui_hud_set_color(0,0,0,70)

    for y=0,h,2 do

        djui_hud_render_rect(
            0,
            y,
            w,
            1
        )

    end


    -- phosphor glow

    djui_hud_set_color(255,255,255,12)

    djui_hud_render_rect(
        0,
        0,
        w,
        h
    )


end



-- VHS tape distortion
local function vhs()

    local w,h = screen()
    local timer = get_global_timer()


    rect(25,25,25,25)


    -- moving tape bands

    for i=1,8 do

        local y =
            (timer * 2 + i * 90) % h


        djui_hud_set_color(
            255,
            255,
            255,
            12
        )


        djui_hud_render_rect(
            math.sin(timer * 0.1) * 8,
            y,
            w,
            2
        )

    end



    -- chromatic tape offset

    djui_hud_set_color(255,0,0,12)

    djui_hud_render_rect(
        -3,
        0,
        w,
        h
    )


    djui_hud_set_color(0,255,255,12)

    djui_hud_render_rect(
        3,
        0,
        w,
        h
    )



    -- noise lines

    for i=1,14 do

        djui_hud_set_color(
            255,
            255,
            255,
            8
        )


        djui_hud_render_rect(
            0,
            math.random(0,h),
            w,
            1
        )

    end

end

-- monochrome green terminal display
local function green()

    local w,h = screen()

    rect(20,80,20,30)


    -- subtle phosphor lines

    djui_hud_set_color(0,255,0,12)

    for y=0,h,4 do

        djui_hud_render_rect(
            0,
            y,
            w,
            1
        )

    end


    -- dark vignette illusion

    djui_hud_set_color(0,0,0,35)

    djui_hud_render_rect(
        0,
        0,
        w,
        h
    )

end



-- pixelated low resolution effect
local function low_res()

    local w,h = screen()


    -- pixel grid/dithering illusion

    djui_hud_set_color(
        0,
        0,
        0,
        22
    )


    for y=0,h,4 do

        for x=0,w,4 do

            if (x+y) % 8 == 0 then

                djui_hud_render_rect(
                    x,
                    y,
                    2,
                    2
                )

            end

        end

    end


    -- reduced color feeling

    rect(40,40,40,10)

end



-- digital corruption
local function glitch()

    local w,h = screen()
    local timer = get_global_timer()


    -- shifting RGB channels

    local shift =
        math.sin(timer * 0.3) * 6


    djui_hud_set_color(
        255,
        0,
        50,
        18
    )

    djui_hud_render_rect(
        shift,
        0,
        w,
        h
    )


    djui_hud_set_color(
        0,
        255,
        255,
        18
    )

    djui_hud_render_rect(
        -shift,
        0,
        w,
        h
    )


    -- corruption blocks

    for i=1,16 do

        local y =
            math.random(0,h)

        djui_hud_set_color(
            math.random(80,255),
            math.random(80,255),
            math.random(80,255),
            30
        )


        djui_hud_render_rect(
            math.random(-20,20),
            y,
            w * math.random(20,80) / 100,
            math.random(2,8)
        )

    end

end



-- dark arcade CRT
local function crt_dark()

    local w,h = screen()


    rect(5,5,15,45)



    -- thick scanlines

    djui_hud_set_color(
        0,
        0,
        0,
        65
    )


    for y=0,h,3 do

        djui_hud_render_rect(
            0,
            y,
            w,
            2
        )

    end



    -- monitor glow

    djui_hud_set_color(
        20,
        40,
        60,
        12
    )

    djui_hud_render_rect(
        0,
        0,
        w,
        h
    )

end



-- layered blur simulation
local function blur()

    local w,h = screen()


    -- multiple translucent offsets create actual blur

    djui_hud_set_color(
        255,
        255,
        255,
        8
    )


    djui_hud_render_rect(
        -3,
        0,
        w,
        h
    )

    djui_hud_render_rect(
        3,
        0,
        w,
        h
    )


    djui_hud_render_rect(
        0,
        -3,
        w,
        h
    )

    djui_hud_render_rect(
        0,
        3,
        w,
        h
    )


    djui_hud_set_color(
        255,
        255,
        255,
        5
    )


    djui_hud_render_rect(
        -6,
        0,
        w,
        h
    )

    djui_hud_render_rect(
        6,
        0,
        w,
        h
    )


end

-- old film camera effect
local function film()

    local w,h = screen()
    local timer = get_global_timer()


    -- slight faded film color

    rect(
        90,
        70,
        40,
        12
    )


    -- moving grain

    for i=1,45 do

        djui_hud_set_color(
            255,
            255,
            255,
            math.random(4,18)
        )

        djui_hud_render_rect(
            math.random(0,w),
            math.random(0,h),
            1,
            1
        )

    end



    -- occasional frame flicker

    if timer % 30 < 2 then

        djui_hud_set_color(
            255,
            255,
            255,
            20
        )

        djui_hud_render_rect(
            0,
            0,
            w,
            h
        )

    end


    -- film scratches

    for i=1,3 do

        djui_hud_set_color(
            255,
            255,
            255,
            20
        )

        djui_hud_render_rect(
            math.random(0,w),
            0,
            1,
            h
        )

    end

end



-- heat distortion effect
local function heat_haze()

    local w,h = screen()
    local timer = get_global_timer()


    rect(
        120,
        40,
        10,
        18
    )


    -- moving waves

    for i=1,12 do

        local y =
            (i * 45) +
            math.sin(timer * 0.15 + i) * 8


        djui_hud_set_color(
            255,
            140,
            50,
            15
        )


        djui_hud_render_rect(
            math.sin(timer * 0.2 + i) * 8,
            y,
            w,
            3
        )

    end



    -- bright shimmer

    for i=1,5 do

        djui_hud_set_color(
            255,
            220,
            120,
            10
        )

        djui_hud_render_rect(
            math.random(-10,10),
            math.random(0,h),
            w,
            1
        )

    end

end



-- underwater distortion
local function underwater()

    local w,h = screen()
    local timer = get_global_timer()


    rect(
        0,
        80,
        180,
        30
    )


    -- moving water bands

    for i=1,12 do

        local y =
            (timer + i * 60) % h


        djui_hud_set_color(
            80,
            160,
            255,
            15
        )


        djui_hud_render_rect(
            math.sin(timer * 0.08 + i) * 10,
            y,
            w,
            2
        )

    end



    -- bubbles

    for i=1,14 do

        local x =
            (i * 83 + timer) % w

        local y =
            (h - ((timer * 1.5 + i * 50) % h))


        djui_hud_set_color(
            200,
            240,
            255,
            25
        )


        djui_hud_render_rect(
            x,
            y,
            2,
            2
        )

    end

end



-- cyber grid overlay
local function gridlock()

    local w,h = screen()


    -- dark digital background

    rect(
        10,
        0,
        25,
        20
    )



    -- vertical grid

    for x=0,w,40 do

        djui_hud_set_color(
            0,
            255,
            255,
            18
        )

        djui_hud_render_rect(
            x,
            0,
            1,
            h
        )

    end



    -- horizontal grid

    for y=0,h,40 do

        djui_hud_set_color(
            255,
            0,
            255,
            18
        )

        djui_hud_render_rect(
            0,
            y,
            w,
            1
        )

    end

end



-- analog television snow/static
local function fuzzy_signal()

    local w,h = screen()


    rect(
        80,
        80,
        80,
        20
    )


    -- static noise

    for i=1,120 do

        local shade =
            math.random(40,255)


        djui_hud_set_color(
            shade,
            shade,
            shade,
            20
        )


        djui_hud_render_rect(
            math.random(0,w),
            math.random(0,h),
            math.random(1,3),
            math.random(1,3)
        )

    end



    -- weak scanline signal

    djui_hud_set_color(
        0,
        0,
        0,
        35
    )


    for y=0,h,4 do

        djui_hud_render_rect(
            0,
            y,
            w,
            1
        )

    end

end

-- CRT vertical sync failure
local function sync_loss()

    local w,h = screen()
    local timer = get_global_timer()


    -- background CRT darkness

    rect(
        10,
        10,
        20,
        35
    )


    -- moving vertical hold position

    local sync_position =
        math.sin(timer * 0.08) * (h * 0.35)
        + (h * 0.5)



    -- bouncing scanline distortion

    for y=0,h,3 do

        local offset =
            math.sin((y + timer * 3) * 0.08) * 6


        local distance =
            math.abs(y - sync_position)


        local intensity = 35


        if distance < 80 then
            intensity = 90
        end


        djui_hud_set_color(
            0,
            0,
            0,
            intensity
        )


        djui_hud_render_rect(
            offset,
            y,
            w,
            1
        )

    end



    -- RGB separation during sync failure

    local shift =
        math.sin(timer * 0.15) * 8


    djui_hud_set_color(
        255,
        0,
        0,
        18
    )

    djui_hud_render_rect(
        -shift,
        0,
        w,
        h
    )


    djui_hud_set_color(
        0,
        255,
        255,
        18
    )

    djui_hud_render_rect(
        shift,
        0,
        w,
        h
    )



    -- horizontal tearing around the failed sync point

    for i=1,3 do

        local tear_y =
            sync_position +
            math.random(-40,40)


        djui_hud_set_color(
            255,
            255,
            255,
            25
        )


        djui_hud_render_rect(
            math.random(-20,20),
            tear_y,
            w,
            math.random(2,5)
        )

    end

end



-- corrupted inverted signal
local function oiram_88()

    local w,h = screen()
    local timer = get_global_timer()


    -- harsh negative screen

    rect(
        255,
        255,
        255,
        70
    )


    djui_hud_set_color(
        0,
        0,
        0,
        45
    )

    djui_hud_render_rect(
        0,
        0,
        w,
        h
    )



    -- inverted scanlines

    for y=0,h,4 do

        djui_hud_set_color(
            255,
            255,
            255,
            35
        )


        djui_hud_render_rect(
            0,
            y,
            w,
            2
        )

    end



    -- unstable red corruption

    if timer % 10 < 4 then

        djui_hud_set_color(
            255,
            0,
            0,
            35
        )


        djui_hud_render_rect(
            0,
            0,
            w,
            h
        )

    end



    -- random signal breaks

    for i=1,8 do

        djui_hud_set_color(
            255,
            255,
            255,
            20
        )


        djui_hud_render_rect(
            math.random(-10,10),
            math.random(0,h),
            w,
            math.random(1,3)
        )

    end

end



local function draw_overlay()

    local m = gGlobalSyncTable.overlay_mode


    if m == 0 then off()
    elseif m == 1 then n64()
    elseif m == 2 then washed()
    elseif m == 3 then retro_crt()
    elseif m == 4 then vhs()
    elseif m == 5 then green()
    elseif m == 6 then low_res()
    elseif m == 7 then glitch()
    elseif m == 8 then crt_dark()
    elseif m == 9 then blur()
    elseif m == 10 then film()
    elseif m == 11 then heat_haze()
    elseif m == 12 then underwater()
    elseif m == 13 then gridlock()
    elseif m == 14 then fuzzy_signal()
    elseif m == 15 then sync_loss()
    elseif m == 16 then oiram_88()
    end

end



local function trigger_list()

    list_timer = 90

end



local function cycle_overlay(dir)

    gGlobalSyncTable.overlay_mode =
        gGlobalSyncTable.overlay_mode + dir


    if gGlobalSyncTable.overlay_mode > 16 then
        gGlobalSyncTable.overlay_mode = 0
    end


    if gGlobalSyncTable.overlay_mode < 0 then
        gGlobalSyncTable.overlay_mode = 16
    end


    trigger_list()

end

hook_event(HOOK_UPDATE, function()

    local p = gMarioStates[0]

    if not p or not p.controller then return end


    if list_timer > 0 then

        list_timer = list_timer - 1
        list_alpha = math.min(list_alpha + 20,180)

    else

        list_alpha = math.max(list_alpha - 15,0)

    end



    if keybindsEnabled then


        if (p.controller.buttonPressed & L_TRIG) ~= 0 then

            cycle_overlay(1)

        end



        local period =
            (p.controller.buttonPressed & X_BUTTON) ~= 0


        local comma =
            (p.controller.buttonPressed & Y_BUTTON) ~= 0



        if period and not prevPeriod then

            cycle_overlay(1)

        end



        if comma and not prevComma then

            cycle_overlay(-1)

        end



        prevPeriod = period
        prevComma = comma

    end

end)



hook_event(HOOK_ON_HUD_RENDER, function()

    draw_overlay()



    if showUI then


        local w,h = screen()


        local box_x = 20
        local box_y = (h * 0.76) + 35



        djui_hud_set_color(
            0,
            0,
            0,
            140
        )


        djui_hud_render_rect(
            box_x,
            box_y,
            250,
            40
        )



        djui_hud_set_color(
            255,
            255,
            255,
            255
        )


        djui_hud_print_text(
            "Overlay Mode: " ..
            overlay_names[gGlobalSyncTable.overlay_mode + 1],
            box_x + 10,
            box_y + 12,
            0.6
        )



        local btn_w,btn_h = 120,50

        local btn_x =
            w - btn_w - 20

        local btn_y =
            h - btn_h - 20



        djui_hud_set_color(
            0,
            0,
            0,
            160
        )


        djui_hud_render_rect(
            btn_x,
            btn_y,
            btn_w,
            btn_h
        )



        djui_hud_set_color(
            255,
            255,
            255,
            255
        )


        djui_hud_print_text(
            "OVERLAY",
            btn_x + 25,
            btn_y + 18,
            0.7
        )



        if list_alpha > 0 then


            local list_x = 20
            local list_y = 120



            djui_hud_set_color(
                0,
                0,
                0,
                list_alpha
            )


            djui_hud_render_rect(
                list_x,
                list_y,
                230,
                300
            )



            for i=0,16 do


                local y =
                    list_y + 10 + (i * 16)



                if gGlobalSyncTable.overlay_mode == i then


                    djui_hud_set_color(
                        80,
                        220,
                        120,
                        list_alpha
                    )


                else


                    djui_hud_set_color(
                        200,
                        200,
                        200,
                        list_alpha
                    )


                end



                djui_hud_print_text(
                    overlay_names[i + 1],
                    list_x + 10,
                    y,
                    0.65
                )


            end

        end

    end

end)



hook_mod_menu_checkbox(
    "Show Mode Indicator",
    false,
    function(index,value)

        showUI = value

    end
)



hook_mod_menu_checkbox(
    "Enable Keybindings",
    true,
    function(index,value)

        keybindsEnabled = value

    end
)



hook_mod_menu_text(
    "0=Off  1=N64 CRT  2=Washed  3=Retro CRT  4=VHS"
)

hook_mod_menu_text(
    "5=Green  6=Low-Res  7=Glitch  8=CRT Dark  9=Blur"
)

hook_mod_menu_text(
    "10=Film  11=Heat Haze  12=Underwater"
)

hook_mod_menu_text(
    "13=Gridlock  14=Fuzzy Signal"
)

hook_mod_menu_text(
    "15=Sync Loss  16=Oiram 88"
)



hook_mod_menu_slider(
    "Filter Mode",
    0,
    0,
    16,
    function(index,value)

        gGlobalSyncTable.overlay_mode = value

    end
)