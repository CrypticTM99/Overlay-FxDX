-- name: OverlayFxDX-v1.1.4-TEST
-- description: Overlay system for COOPDX 1.5.1, Created by CrypticTM

if gGlobalSyncTable == nil then gGlobalSyncTable = {} end
if gGlobalSyncTable.overlay_mode == nil then gGlobalSyncTable.overlay_mode = 0 end
if gGlobalSyncTable.test_overlay_mode == nil then gGlobalSyncTable.test_overlay_mode = 0 end

local showUI = false
local keybindsEnabled = true

local overlay_names = {
    "OFF/NORMAL", "N64 CRT", "WASHED COLORS", "RETRO v1 (CRT)", "VHS",
    "GREEN", "LOW-RES", "GLITCH", "CRT (DARK)", "BLUR",
    "FILM", "HEAT HAZE", "UNDERWATER", "GRIDLOCK", "FUZZY SIGNAL"
}

local test_overlay_names = {
    "OFF/TEST",
    "SYNC LOSS",
    "OIRAM 88"
}

local prevPeriod = false
local prevComma = false

local list_timer = 0
local list_alpha = 0

local function screen()
    return djui_hud_get_screen_width(), djui_hud_get_screen_height()
end

local function rect(r,g,b,a)
    local w,h = screen()
    djui_hud_set_color(r,g,b,a)
    djui_hud_render_rect(0,0,w,h)
end

local function off() end

local function n64()
    local w,h = screen()
    rect(20,20,40,30)

    djui_hud_set_color(0,0,0,40)
    for y=0,h,3 do
        djui_hud_render_rect(0,y,w,1)
    end
end

local function bw()
    rect(120,120,120,35)
end

local function ps1()
    local w,h = screen()
    rect(90,60,120,25)

    djui_hud_set_color(0,0,0,50)
    for y=0,h,8 do
        djui_hud_render_rect(0,y,w,2)
    end
end

local function vhs()
    local w,h = screen()

    rect(35,35,35,22)

    for i=1,12 do
        local offset = math.random(-6,6)
        djui_hud_set_color(255,255,255,10)
        djui_hud_render_rect(offset, math.random(0,h), w, 1)
    end

    for i=1,10 do
        djui_hud_set_color(200,200,200,6)
        djui_hud_render_rect(0, math.random(0,h), w, 2)
    end

    djui_hud_set_color(0,0,0,25)
    for y=0,h,4 do
        djui_hud_render_rect(0,y + math.random(-1,1),w,1)
    end
end

local function green()
    rect(40,120,40,35)
end

local function invert()
    rect(255,255,255,20)
end

local function glitch()
    local w,h = screen()

    for i=1,18 do
        djui_hud_set_color(math.random(0,255),0,math.random(0,255),40)
        djui_hud_render_rect(math.random(0,w),math.random(0,h),120,2)
    end
end

local function crt()
    local w,h = screen()

    rect(10,10,20,35)

    djui_hud_set_color(0,0,0,45)
    for y=0,h,2 do
        djui_hud_render_rect(0,y,w,1)
    end
end

local function blur()
    local w,h = screen()

    rect(255,245,220,6)

    djui_hud_set_color(0,0,0,35)
    djui_hud_render_rect(-10,0,20,h)
    djui_hud_render_rect(w-10,0,20,h)

    djui_hud_set_color(255,255,255,8)
    djui_hud_render_rect(1,0,w,h)
    djui_hud_render_rect(-1,0,w,h)

    djui_hud_set_color(0,0,0,35)
    for y=0,h,3 do
        djui_hud_render_rect(0,y,w,1)
    end

    djui_hud_set_color(255,220,120,18)
    for i=1,12 do
        djui_hud_render_rect(i*2,i,w*0.6,2)
    end
end

local function noir()
    local w,h = screen()

    for y=0,h,2 do
        local lum = math.random(40,220)
        djui_hud_set_color(lum,lum,lum,20)
        djui_hud_render_rect(0,y,w,2)
    end

    djui_hud_set_color(0,0,0,10)
    djui_hud_render_rect(0,0,w,h)
end

local function heat()
    local w,h = screen()

    djui_hud_set_color(120,40,10,25)
    djui_hud_render_rect(0,0,w,h)

    for i=1,18 do
        djui_hud_set_color(255,math.random(80,140),40,25)
        djui_hud_render_rect(math.random(-2,2),math.random(0,h),w,2)
    end

    for i=1,6 do
        djui_hud_set_color(255,120,60,12)
        djui_hud_render_rect(math.random(-4,4),math.random(-4,4),w,h)
    end
end

local function underwater()
    local w,h = screen()

    rect(0,120,200,22)

    djui_hud_set_color(120,180,255,14)
    djui_hud_render_rect(0,0,w,h)

    djui_hud_set_color(80,140,255,10)
    djui_hud_render_rect(0,0,w,h)

    djui_hud_set_color(200,230,255,12)

    for i=1,14 do
        djui_hud_render_rect(
            math.random(0,w),
            math.random(0,h),
            2,
            2
        )
    end
end


local function neon()
    local w,h = screen()

    for x=0,w,40 do
        for glow=1,3 do
            djui_hud_set_color(0,255,255,10 - glow * 2)
            djui_hud_render_rect(x - glow,0,2 + glow * 2,h)
        end
    end

    for y=0,h,30 do
        for glow=1,3 do
            djui_hud_set_color(255,0,255,10 - glow * 2)
            djui_hud_render_rect(0,y - glow,w,2 + glow * 2)
        end
    end
end


local function broken()
    local w,h = screen()

    for i=1,25 do
        djui_hud_set_color(
            math.random(0,255),
            math.random(0,255),
            math.random(0,255),
            20
        )

        djui_hud_render_rect(
            math.random(0,w),
            math.random(0,h),
            math.random(20,120),
            2
        )
    end

    for i=1,120 do
        djui_hud_set_color(0,0,0,255)

        djui_hud_render_rect(
            math.random(0,w),
            math.random(0,h),
            math.random(2,6),
            math.random(2,6)
        )
    end
end


--testing effects below, dont worry about these, they'll get pushed to regular list.

local function sync_loss()
    local w,h = screen()
    local timer = get_global_timer()

    local bounce = math.sin(timer * 0.25) * 8

    rect(15,15,25,25)

    -- CRT scanline movement
    djui_hud_set_color(0,0,0,45)
    for y=0,h,3 do
        djui_hud_render_rect(
            0,
            y + bounce,
            w,
            1
        )
    end

    -- RGB signal separation
    djui_hud_set_color(255,0,0,20)
    djui_hud_render_rect(
        -bounce,
        0,
        w,
        h
    )

    djui_hud_set_color(0,255,255,20)
    djui_hud_render_rect(
        bounce,
        0,
        w,
        h
    )

    -- occasional horizontal tearing
    if timer % 20 < 4 then
        djui_hud_set_color(255,255,255,25)
        djui_hud_render_rect(
            math.random(-10,10),
            math.random(0,h),
            w,
            3
        )
    end
end


local function oiram_88()
    local w,h = screen()

    -- negative color effect
    rect(255,255,255,80)

    djui_hud_set_color(0,0,0,35)
    djui_hud_render_rect(0,0,w,h)

    -- harsh inverted scanlines
    for y=0,h,4 do
        djui_hud_set_color(255,255,255,25)
        djui_hud_render_rect(
            0,
            y,
            w,
            2
        )
    end

    -- I'll remove the 'test' overlays and include them in the regular list later
    if get_global_timer() % 8 < 2 then
        djui_hud_set_color(255,0,0,25)
        djui_hud_render_rect(0,0,w,h)
    end
end

local function draw_overlay()
    local m = gGlobalSyncTable.overlay_mode
    local t = gGlobalSyncTable.test_overlay_mode

    if t == 1 then
        sync_loss()
        return
    elseif t == 2 then
        oiram_88()
        return
    end

    if m == 0 then off()
    elseif m == 1 then n64()
    elseif m == 2 then bw()
    elseif m == 3 then ps1()
    elseif m == 4 then vhs()
    elseif m == 5 then green()
    elseif m == 6 then invert()
    elseif m == 7 then glitch()
    elseif m == 8 then crt()
    elseif m == 9 then blur()
    elseif m == 10 then noir()
    elseif m == 11 then heat()
    elseif m == 12 then underwater()
    elseif m == 13 then neon()
    elseif m == 14 then broken()
    end
end


local function trigger_list()
    list_timer = 90
end


local function cycle_overlay(dir)
    gGlobalSyncTable.overlay_mode = gGlobalSyncTable.overlay_mode + dir

    if gGlobalSyncTable.overlay_mode > 14 then
        gGlobalSyncTable.overlay_mode = 0
    end

    if gGlobalSyncTable.overlay_mode < 0 then
        gGlobalSyncTable.overlay_mode = 14
    end

    gGlobalSyncTable.test_overlay_mode = 0

    trigger_list()
end


hook_event(HOOK_UPDATE, function()
    local p = gMarioStates[0]

    if not p or not p.controller then return end

    if list_timer > 0 then
        list_timer = list_timer - 1
        list_alpha = math.min(list_alpha + 20,180)
    else
        list_alpha = math.max(list_alpha - 15,0)
    end


    if keybindsEnabled then

        if (p.controller.buttonPressed & L_TRIG) ~= 0 then
            cycle_overlay(1)
        end


        local period = (p.controller.buttonPressed & X_BUTTON) ~= 0
        local comma = (p.controller.buttonPressed & Y_BUTTON) ~= 0


        if period and not prevPeriod then
            cycle_overlay(1)
        end

        if comma and not prevComma then
            cycle_overlay(-1)
        end


        prevPeriod = period
        prevComma = comma
    end
end)



hook_event(HOOK_ON_HUD_RENDER, function()

    draw_overlay()


    if showUI then

        local w,h = screen()

        local box_x = 20
        local box_y = (h * 0.76) + 35


        djui_hud_set_color(0,0,0,140)
        djui_hud_render_rect(
            box_x,
            box_y,
            240,
            40
        )


        djui_hud_set_color(255,255,255,255)

        local mode_text

        if gGlobalSyncTable.test_overlay_mode > 0 then
            mode_text = test_overlay_names[gGlobalSyncTable.test_overlay_mode + 1]
        else
            mode_text = overlay_names[gGlobalSyncTable.overlay_mode + 1]
        end


        djui_hud_print_text(
            "Overlay Mode: " .. mode_text,
            box_x + 10,
            box_y + 12,
            0.6
        )



        local btn_w,btn_h = 120,50
        local btn_x = w - btn_w - 20
        local btn_y = h - btn_h - 20


        djui_hud_set_color(0,0,0,160)
        djui_hud_render_rect(
            btn_x,
            btn_y,
            btn_w,
            btn_h
        )


        djui_hud_set_color(255,255,255,255)

        djui_hud_print_text(
            "OVERLAY",
            btn_x + 25,
            btn_y + 18,
            0.7
        )



        if list_alpha > 0 then

            local list_x = 20
            local list_y = 145


            djui_hud_set_color(
                0,
                0,
                0,
                list_alpha
            )

            djui_hud_render_rect(
                list_x,
                list_y,
                200,
                310
            )


            for i = 0,14 do

                local y = list_y + 10 + (i * 16)


                if gGlobalSyncTable.test_overlay_mode == 0
                and gGlobalSyncTable.overlay_mode == i then

                    djui_hud_set_color(
                        80,
                        220,
                        120,
                        list_alpha
                    )

                else

                    djui_hud_set_color(
                        200,
                        200,
                        200,
                        list_alpha
                    )

                end


                djui_hud_print_text(
                    overlay_names[i + 1],
                    list_x + 10,
                    y,
                    0.7
                )
            end



            local test_y = list_y + 250


            djui_hud_set_color(
                255,
                200,
                80,
                list_alpha
            )


            djui_hud_print_text(
                "TEST EFFECTS",
                list_x + 10,
                test_y,
                0.7
            )


            for i = 1,2 do

                local y = test_y + 18 + (i * 16)


                if gGlobalSyncTable.test_overlay_mode == i then

                    djui_hud_set_color(
                        80,
                        220,
                        120,
                        list_alpha
                    )

                else

                    djui_hud_set_color(
                        200,
                        200,
                        200,
                        list_alpha
                    )

                end


                djui_hud_print_text(
                    test_overlay_names[i + 1],
                    list_x + 10,
                    y,
                    0.7
                )
            end
        end
    end
end)



hook_mod_menu_checkbox(
    "Show Mode Indicator",
    false,
    function(index,value)
        showUI = value
    end
)


hook_mod_menu_checkbox(
    "Enable Keybindings",
    true,
    function(index,value)
        keybindsEnabled = value
    end
)


hook_mod_menu_text("0=Off  1=N64 CRT  2=Washed  3=Retro CRT  4=VHS")
hook_mod_menu_text("5=Green  6=Low-Res  7=Glitch  8=CRT Dark  9=Blur")
hook_mod_menu_text("10=Film  11=Heat Haze  12=Underwater  13=Gridlock  14=Fuzzy")

hook_mod_menu_slider(
    "Filter Mode",
    0,
    0,
    14,
    function(index,value)
        gGlobalSyncTable.overlay_mode = value
        gGlobalSyncTable.test_overlay_mode = 0
    end
)


hook_mod_menu_text("TESTING NEW EFFECTS")
hook_mod_menu_text("1=Sync Loss  2=Oiram 88")


hook_mod_menu_slider(
    "Test Filter Mode",
    0,
    0,
    2,
    function(index,value)
        gGlobalSyncTable.test_overlay_mode = value

        if value > 0 then
            gGlobalSyncTable.overlay_mode = 0
        end
    end
)